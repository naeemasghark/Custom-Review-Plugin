<?php

// Add an options page to the WordPress dashboard
function crp_add_admin_menu() {
    add_menu_page(
        'Custom Review Plugin Settings',
        'Review Settings',
        'manage_options',
        'crp_settings',
        'crp_settings_page',
        'dashicons-star-filled',
        100
    );
}
add_action('admin_menu', 'crp_add_admin_menu');

// Register settings
function crp_register_settings() {
    register_setting('crp_settings_group', 'crp_gbp_url');
    register_setting('crp_settings_group', 'crp_admin_email');
}
add_action('admin_init', 'crp_register_settings');

// Create the settings page
function crp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom Review Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('crp_settings_group');
            do_settings_sections('crp_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Google Business Profile URL</th>
                    <td><input type="url" name="crp_gbp_url" value="<?php echo esc_attr(get_option('crp_gbp_url')); ?>" size="50" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Admin Email for Low Ratings</th>
                    <td><input type="email" name="crp_admin_email" value="<?php echo esc_attr(get_option('crp_admin_email')); ?>" size="50" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
