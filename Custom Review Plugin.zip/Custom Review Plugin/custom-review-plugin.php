<?php
/*
Plugin Name: Custom Review Plugin
Plugin URI:  https://naeemasghar.dev/
Description: A custom review submission plugin that redirects based on star rating.
Version:     1.0
Author:      Naeem Asghar Kamboh
Author URI:  https://naeemasghar.dev/
*/

// Include additional functionality files
include_once plugin_dir_path(__FILE__) . 'includes/admin-settings.php';
include_once plugin_dir_path(__FILE__) . 'includes/form-handler.php';

// Enqueue assets
function crp_enqueue_assets() {
    wp_enqueue_style('crp-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('crp-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), null, true);
    wp_localize_script('crp-script', 'crp_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'crp_enqueue_assets');

// Register the shortcode for the review form
function crp_review_form_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/review-form.php';
    return ob_get_clean();
}
add_shortcode('crp_review_form', 'crp_review_form_shortcode');
