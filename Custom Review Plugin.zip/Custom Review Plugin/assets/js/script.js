document.querySelectorAll('.star').forEach(star => {
    star.addEventListener('click', function() {
        let rating = this.getAttribute('data-value');
        document.getElementById('rating').value = rating;

        // Highlight stars based on selection
        document.querySelectorAll('.star').forEach(s => {
            s.style.color = (s.getAttribute('data-value') <= rating) ? '#FFD700' : '#FFFFFF';
        });

        // Handle rating action
        if (rating >= 4) {
            // Redirect to Google Business Profile if rating is 4 or 5 stars
            window.location.href = crp_ajax_object.crp_gbp_url;
        } else {
            // Show comment box for ratings 1-3
            document.getElementById('comment-box').style.display = 'block';
        }
    });
});

// Handle form submission for low ratings (1-3 stars)
document.getElementById('crp-review-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent default form submission
    var rating = document.getElementById('rating').value;
    var message = document.getElementById('message').value;

    // Send the feedback if the rating is low
    if (rating <= 3) {
        var formData = new FormData();
        formData.append('action', 'crp_handle_form_submission');
        formData.append('rating', rating);
        formData.append('message', message);

        fetch(crp_ajax_object.ajax_url, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(result => {
            alert('Thank you for your feedback!');
            document.getElementById('comment-box').style.display = 'none';
        })
        .catch(error => console.error('Error:', error));
    }
});
